package aspectJ1;

public @interface MyAnnotation {

}
