package services;

public class Service {
	
	public void method() {
//		System.out.println("service method in services package");
		method2();
	}
	
	private void method2() {
	}

}
