package services;

public class Test {
	
	public void method() {
		System.out.println("Test method in services package");
	}

}
